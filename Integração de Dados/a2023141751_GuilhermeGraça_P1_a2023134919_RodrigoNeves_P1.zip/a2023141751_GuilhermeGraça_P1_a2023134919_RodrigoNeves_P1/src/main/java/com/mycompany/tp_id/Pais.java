package com.mycompany.tp_id;

import java.util.ArrayList;

public class Pais {
    private String nome, continente, presidente, flag, capital, populacao, area, densidadePopulacional, casosCovid;
    private ArrayList<String> cidades_pop, vizinhos, idiomas_ofc, religioes;

    public Pais(String nome, String continente, String presidente, String flag, String capital, String populacao, String area, String densidadePopulacional, String casosCovid, ArrayList<String> cidades_pop, ArrayList<String> vizinhos, ArrayList<String> idiomas_ofc, ArrayList<String> religioes) {
        this.nome = nome;
        this.continente = continente;
        this.presidente = presidente;
        this.flag = flag;
        this.capital = capital;
        this.populacao = populacao;
        this.area = area;
        this.densidadePopulacional = densidadePopulacional;
        this.casosCovid = casosCovid;
        this.cidades_pop = cidades_pop;
        this.vizinhos = vizinhos;
        this.idiomas_ofc = idiomas_ofc;
        this.religioes = religioes;
    }

    public String getNome() {
        return nome;
    }

    public String getContinente() {
        return continente;
    }

    public String getPresidente() {
        return presidente;
    }

    public String getFlag() {
        return flag;
    }

    public String getCapital() {
        return capital;
    }

    public String getPopulacao() {
        return populacao;
    }

    public String getArea() {
        return area;
    }

    public String getDensidadePopulacional() {
        return densidadePopulacional;
    }

    public String getCasosCovid() {
        return casosCovid;
    }

    public ArrayList<String> getCidades_pop() {
        return cidades_pop;
    }

    public ArrayList<String> getVizinhos() {
        return vizinhos;
    }

    public ArrayList<String> getIdiomas_ofc() {
        return idiomas_ofc;
    }

    public ArrayList<String> getReligioes() {
        return religioes;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setContinente(String continente) {
        this.continente = continente;
    }

    public void setPresidente(String presidente) {
        this.presidente = presidente;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public void setPopulacao(String populacao) {
        this.populacao = populacao;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public void setDensidadePopulacional(String densidadePopulacional) {
        this.densidadePopulacional = densidadePopulacional;
    }

    public void setCasosCovid(String casosCovid) {
        this.casosCovid = casosCovid;
    }

    public void setCidades_pop(ArrayList<String> cidades_pop) {
        this.cidades_pop = cidades_pop;
    }

    public void setVizinhos(ArrayList<String> vizinhos) {
        this.vizinhos = vizinhos;
    }

    public void setIdiomas_ofc(ArrayList<String> idiomas_ofc) {
        this.idiomas_ofc = idiomas_ofc;
    }

    public void setReligioes(ArrayList<String> religioes) {
        this.religioes = religioes;
    }
}
