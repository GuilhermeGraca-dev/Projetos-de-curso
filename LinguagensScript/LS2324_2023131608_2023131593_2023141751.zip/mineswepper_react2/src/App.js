import './App.css';
import { ControlPanel, GamePanel } from './components';
import { useState } from 'react';

function App() {
  const [quadrados, setQuadrados] = useState([]);
  const [nivel, setNivel] = useState(0);
  const [gameStarted, setGameStarted] = useState(false);
  const [bandeiras, setBandeiras] = useState(0);
  const [textoFim, setTextoFim] = useState("");
  const [nivelSelected, setNivelSelected] = useState("");

  function handleTextoFim(texto){
    setTextoFim(texto);
  }

  function handleBandeiras(valor){
    setBandeiras(valor);
  }

  function handleBandeirasMais(){
    setBandeiras(bandeiras+1);
  }

  function handleGameStarted(){
    setGameStarted(!gameStarted);
  }

  function handleNivel(valor){
    setNivel(valor);
  }

  function handleFlipped(id){
    let aux = quadrados;
    for (let i = 0; i < aux.length; i++){
      if (aux[i].id == id && aux[i].flipped == ""){
        aux[i].flipped = "flipped";
        i = aux.length;
      }
    }
    setQuadrados(aux);
  }

  return (
    <div className = "body">
      <div className={"mainDiv " + nivelSelected} >
          <label className="tituloLbl">MINESWEPPER EM REACT</label>
          <label className="cadeiraLbl">Linguagens Script</label>
          <div className="gameDiv" >
              <ControlPanel 
                nivel={nivel}
                nivelFunc={handleNivel}
                setQuadrados={setQuadrados}
                gameStarted={gameStarted}
                handleGameStarted={handleGameStarted}
                textoFim={textoFim}
                bandeiras={bandeiras}
              />
              <GamePanel 
                quadrados={quadrados}
                nivel={nivel}
                updateQuadrados={setQuadrados}
                flipped={handleFlipped}
                gameStarted={gameStarted}
                handleBandeiras={handleBandeiras}
                bandeiras={bandeiras}
                textoFim={textoFim}
                handleTextoFim={handleTextoFim}
                handleBandeirasMais={handleBandeirasMais}
                nivelSelected={nivelSelected}
                setNivelSelected={setNivelSelected}
              />
          </div>
      </div>
    </div>
  );
}
export default App;

