export const PLACEHOLDER_CARD_PATH = "assets/images/";
export const PLACEHOLDER_CARDBACK_PATH = `${PLACEHOLDER_CARD_PATH}campo.png`;