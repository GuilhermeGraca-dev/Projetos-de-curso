export {default as GamePanel} from "./game-panel/game-panel.component";
export {default as ControlPanel} from "./control-panel/control-panel.component";
export {default as Quadrado} from "./quadrado/quadrado.component";