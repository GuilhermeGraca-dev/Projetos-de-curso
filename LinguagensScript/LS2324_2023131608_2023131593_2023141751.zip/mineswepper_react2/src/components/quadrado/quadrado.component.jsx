import "./quadrado.css";
import { PLACEHOLDER_CARD_PATH } from "../../constants/index.js";
import React, { useEffect, useState } from "react";

export default function Quadrado(props) {
  const [currentBack, setCurrentBack] = useState('campo.png');
  const [currentFront, setCurrentFront] = useState("");
  const bombas = [0, 10, 40, 99];

  function handlecurrentBack(imagem){
    setCurrentBack(imagem);
  }

  useEffect(() => {
    if (props.textoFim == "BOOMMMMM!!! Fim de jogo" && currentBack == "bandeira.png" && props.nome == "bomba.png"){
      setCurrentFront("bandeiraCampoVermelho.png");
    }
  }, [props.textoFim]);

  useEffect(() => {
    if (props.gameStarted == true && props.campos == bombas[props.nivel]){
      props.handleTextoFim("GANHASTE!! Fim de jogo");
    }
  }, [props.campos]);

  useEffect(() => {
    if (props.flipped == "flipped" && currentBack == "bandeira.png" && props.nome != "bomba.png"){
      handlecurrentBack("campo.png");
      props.handleBandeirasMais();
    }
  }, [props.flipped]);

  useEffect(() => {
    if (currentFront == "bomba-perdeu.png"){
      setCurrentFront("bomba.png");
    }
    if (currentFront == "bandeiraCampoVermelho.png"){
      setCurrentFront("bomba.png");
    }
    setCurrentBack("campo.png");
    props.handleTextoFim("");
  }, [props.gameStarted]);

  function handleOnLeftClick(event){
    if (props.campos > bombas[props.nivel]){
      if (props.gameStarted == true && currentBack != "bandeira.png" && currentBack != "bandeira.png" && props.textoFim != "GANHASTE!! Fim de jogo" && props.textoFim != "BOOMMMMM!!! Fim de jogo"){
        let aux = props.quadrados;
        const updatedQuadrados = aux.map(quadrado => {
            if (quadrado.id === props.id){
              return { ...quadrado, flipped: "flipped" };
            }
            else{
              return quadrado;
            }
          }
        );
        props.updateQuadrados(updatedQuadrados);
        if (event.target.id == "bomba.png"){
          props.handleTextoFim("BOOMMMMM!!! Fim de jogo");
          setCurrentFront("bomba-perdeu.png");
          props.mostarBombas();
        }
        else{
          props.recursiva(props.id, updatedQuadrados);
        }
      }
    }
    else if (props.textoFim != "GANHASTE!! Fim de jogo" && props.textoFim != "BOOMMMMM!!! Fim de jogo"){
      let aux = props.quadrados;
      const updatedQuadrados = aux.map(quadrado => {
          if (quadrado.id === props.id){
            return { ...quadrado, flipped: "flipped" };
          }
          else{
            return quadrado;
          }
        }
      );
      props.updateQuadrados(updatedQuadrados);
    }
  };

  function handleOnRightClick(event){
    event.preventDefault();

    if (props.gameStarted == true && props.textoFim != "BOOMMMMM!!! Fim de jogo" && props.textoFim != "GANHASTE!! Fim de jogo"){
      if (currentBack == "campo.png" && props.bandeiras <= bombas[props.nivel] && props.bandeiras > 0){
        handlecurrentBack("bandeira.png")
        props.handleBandeiras(props.bandeiras-1)
      }
      else if (currentBack == "interrogacao.png"){
        handlecurrentBack("campo.png")
      }
      else if (currentBack == "bandeira.png"){
        handlecurrentBack("interrogacao.png")
        props.handleBandeiras(props.bandeiras+1)
      }
    }
  }

  //currentFront = campoVermelho e bomba-perdeu
  return (
    <div className={"quadrado " + (props.flipped ? "flipped" : "")}>
      <img src={PLACEHOLDER_CARD_PATH + currentBack} id={props.nome} className='quadrado-back' onClick={handleOnLeftClick} onContextMenu={handleOnRightClick} />
      
      <img src={PLACEHOLDER_CARD_PATH + (currentFront || props.nome)} onContextMenu={handleOnRightClick} className="quadrado-front" />
    </div>
  );
}
