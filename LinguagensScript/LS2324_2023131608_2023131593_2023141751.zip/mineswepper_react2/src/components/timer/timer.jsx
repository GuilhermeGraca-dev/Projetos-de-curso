import { useState, useEffect } from "react";

function Timer({ timeout, textoFimJogo }) {
  const [seconds, setSeconds] = useState(timeout);

  useEffect(() => {
    const interval = setInterval(() => {
        setSeconds((prevSeconds) => prevSeconds + 1);
    }, 1000);
    
    if (textoFimJogo == "BOOMMMMM!!! Fim de jogo" || textoFimJogo == "GANHASTE!! Fim de jogo"){
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [textoFimJogo]);

  return <>{seconds}</>;
}

export default Timer;