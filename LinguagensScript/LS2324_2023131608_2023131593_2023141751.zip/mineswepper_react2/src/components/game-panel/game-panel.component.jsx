import "./game-panel.css";
import { Quadrado } from "../index";
import { useEffect, useState } from "react";

export default function GamePanel(props) {
  const [campoTotal, setcampoTotal] = useState(props.campos);
  const linhas = [0, 9, 16, 16];
  const colunas = [0, 9, 16, 30];

  function handleCampoTotal(valor){
    setcampoTotal(campoTotal-valor);
  }
  
  useEffect(() => {
    if (props.nivel == 1){
      props.setNivelSelected("");
      setcampoTotal(linhas[props.nivel] * colunas[props.nivel]);
      props.handleBandeiras(10);
    }
    else if (props.nivel == 2){
      props.setNivelSelected("intermedio");
      setcampoTotal(linhas[props.nivel] * colunas[props.nivel]);
      props.handleBandeiras(40);
    }
    else if(props.nivel == 3){
      props.setNivelSelected("avancado");
      setcampoTotal(linhas[props.nivel] * colunas[props.nivel]);
      props.handleBandeiras(99);
    }
  }, [props.nivel, props.gameStarted]);

  function MostrarBombas(){
    let aux = props.quadrados;
    for (let i = 0; i < aux.length; i++){
      if (aux[i].nome == "bomba.png"){
        aux[i].flipped = "flipped";
      }
    }
    props.updateQuadrados(aux);
  }

  function Recursiva(id, quadrados){
    let lenght = quadrados.length;
    let array = 0;

    for (let i = 0; i < lenght; i++){
      if (quadrados[i].id == id){
        array = i;
        i = lenght;
      }
    }
    if (quadrados[array].nome == "campoVazio.png"){
      let campoRetirar;
      campoRetirar = recursivaP(quadrados, array);
      campoRetirar++;
      handleCampoTotal(campoRetirar);
    }
    else{
      handleCampoTotal(1);
    }
  }

  function recursivaP(quadrado, array){
    let coluna = colunas[props.nivel];
    let linha = linhas[props.nivel];
    let camposRecursiva = 0;

    //cima
    if (array - coluna > 0){
      if (quadrado[array-coluna].nome != "campoVazio.png" && quadrado[array-coluna].nome != "bomba.png" && quadrado[array-coluna].flipped != "flipped"){
        quadrado[array-coluna].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if (quadrado[array-coluna].flipped != "flipped" && quadrado[array-coluna].nome == "campoVazio.png" && quadrado[array-coluna].nome != "bomba.png"){
        quadrado[array-coluna].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array - coluna);
      }
      //superior esquerda
      if (array%coluna > 0 && 
        quadrado[array-coluna-1].nome != "campoVazio.png" && 
        quadrado[array-coluna-1].nome != "bomba.png" && 
        quadrado[array-1].nome != "campoVazio.png" && 
        quadrado[array-1].nome != "bomba.png" && 
        quadrado[array-coluna].nome != "campoVazio.png" && 
        quadrado[array-coluna].nome != "bomba.png" && 
        quadrado[array-coluna-1].flipped != "flipped"
      ){
        quadrado[array-coluna-1].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if (array%coluna > 0 && 
        quadrado[array-coluna-1].nome == "campoVazio.png" && 
        quadrado[array-coluna-1].nome != "bomba.png" && 
        quadrado[array-1].nome != "campoVazio.png" && 
        quadrado[array-1].nome != "bomba.png" && 
        quadrado[array-coluna].nome != "campoVazio.png" && 
        quadrado[array-coluna].nome != "bomba.png" && 
        quadrado[array-coluna-1].flipped != "flipped"
      ){
        quadrado[array-coluna].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array - coluna - 1);
      }
      //superior direita
      if ((array+1)%coluna > 0 && 
        quadrado[array-coluna+1].nome != "campoVazio.png" && 
        quadrado[array-coluna+1].nome != "bomba.png" && 
        quadrado[array+1].nome != "campoVazio.png" && 
        quadrado[array+1].nome != "bomba.png" && 
        quadrado[array-coluna].nome != "campoVazio.png" && 
        quadrado[array-coluna].nome != "bomba.png" && 
        quadrado[array-coluna+1].flipped != "flipped"
      ){
        quadrado[array-coluna+1].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if ((array+1)%coluna > 0 && 
        quadrado[array-coluna+1].nome == "campoVazio.png" && 
        quadrado[array-coluna+1].nome != "bomba.png" && 
        quadrado[array+1].nome != "campoVazio.png" && 
        quadrado[array+1].nome != "bomba.png" && 
        quadrado[array-coluna].nome != "campoVazio.png" && 
        quadrado[array-coluna].nome != "bomba.png" && 
        quadrado[array-coluna+1].flipped != "flipped"
      ){
        quadrado[array-coluna+1].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array - coluna + 1);
      }
    }
    //baixo
    if (array + coluna < coluna*linha){
      if (quadrado[array+coluna].nome != "campoVazio.png" && quadrado[array+coluna].nome != "bomba.png" && quadrado[array+coluna].flipped != "flipped"){
        quadrado[array+coluna].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if (quadrado[array+coluna].flipped != "flipped" && quadrado[array+coluna].nome == "campoVazio.png" && quadrado[array+coluna].nome != "bomba.png"){
        quadrado[array+coluna].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array + coluna);
      }
      //inferior esquerda
      if (array%coluna > 0 && 
        quadrado[array+coluna-1].nome != "campoVazio.png" && 
        quadrado[array+coluna-1].nome != "bomba.png" && 
        quadrado[array-1].nome != "campoVazio.png" && 
        quadrado[array-1].nome != "bomba.png" && 
        quadrado[array+coluna].nome != "campoVazio.png" && 
        quadrado[array+coluna].nome != "bomba.png" && 
        quadrado[array+coluna-1].flipped != "flipped"
      ){
        quadrado[array+coluna-1].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if (array%coluna > 0 && 
        quadrado[array+coluna-1].nome == "campoVazio.png" && 
        quadrado[array+coluna-1].nome != "bomba.png" && 
        quadrado[array-1].nome != "campoVazio.png" && 
        quadrado[array-1].nome != "bomba.png" && 
        quadrado[array+coluna].nome != "campoVazio.png" && 
        quadrado[array+coluna].nome != "bomba.png" && 
        quadrado[array+coluna-1].flipped != "flipped"
      ){
        quadrado[array+coluna-1].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array + coluna - 1);
      }
      //inferior direita
      if ((array+1)%coluna > 0 && 
        quadrado[array+coluna+1].nome != "campoVazio.png" && 
        quadrado[array+coluna+1].nome != "bomba.png" && 
        quadrado[array+1].nome != "campoVazio.png" && 
        quadrado[array+1].nome != "bomba.png" && 
        quadrado[array+coluna].nome != "campoVazio.png" && 
        quadrado[array+coluna].nome != "bomba.png" && 
        quadrado[array+coluna+1].flipped != "flipped"
      ){
        quadrado[array+coluna+1].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if ((array+1)%coluna > 0 && 
        quadrado[array+coluna+1].nome == "campoVazio.png" && 
        quadrado[array+coluna+1].nome != "bomba.png" && 
        quadrado[array+1].nome != "campoVazio.png" && 
        quadrado[array+1].nome != "bomba.png" && 
        quadrado[array+coluna].nome != "campoVazio.png" && 
        quadrado[array+coluna].nome != "bomba.png" && 
        quadrado[array+coluna+1].flipped != "flipped"
      ){
        quadrado[array+coluna+1].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array + coluna + 1);
      }
    }
    //esquerda
    if (array%coluna > 0){
      if (quadrado[array-1].nome != "campoVazio.png" && quadrado[array-1].nome != "bomba.png" && quadrado[array-1].flipped != "flipped"){
        quadrado[array-1].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if (quadrado[array-1].flipped != "flipped" && quadrado[array-1].nome == "campoVazio.png" && quadrado[array-1].nome != "bomba.png"){
        quadrado[array-1].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array - 1);
      }
    }
    //direita
    if ((array+1)%coluna > 0){
      if (quadrado[array+1].nome != "campoVazio.png" && quadrado[array+1].nome != "bomba.png" && quadrado[array+1].flipped != "flipped"){
        quadrado[array+1].flipped = "flipped";
        camposRecursiva++;
        props.updateQuadrados(quadrado);
      }
      else if (quadrado[array+1].flipped != "flipped" && quadrado[array+1].nome == "campoVazio.png" && quadrado[array+1].nome != "bomba.png"){
        quadrado[array+1].flipped = "flipped";
        camposRecursiva++;
        camposRecursiva += recursivaP(quadrado, array + 1);
      }
    }
    return camposRecursiva;
  }

  return (
    <section id="panel-game" >
      <div id="game" className={props.nivelSelected} >
        {props.nivel != 0 && props.quadrados.map((quadrado) => (
          <Quadrado 
          key={quadrado.id} 
          id={quadrado.id}
          nome={quadrado.nome} 
          numero={quadrado.numero} 
          flipped={quadrado.flipped} 
          handleFlipped={props.flipped} 
          handleBandeiras={props.handleBandeiras}
          gameStarted={props.gameStarted}
          bandeiras={props.bandeiras}
          nivel={props.nivel}
          recursiva={Recursiva}
          quadrados={props.quadrados}
          updateQuadrados={props.updateQuadrados}
          handleTextoFim={props.handleTextoFim}
          textoFim={props.textoFim}
          mostarBombas={MostrarBombas}
          campos={campoTotal}
          handleCampos={handleCampoTotal}
          handleBandeirasMais={props.handleBandeirasMais}
          />
        ))}
      </div>
    </section>
  );
}