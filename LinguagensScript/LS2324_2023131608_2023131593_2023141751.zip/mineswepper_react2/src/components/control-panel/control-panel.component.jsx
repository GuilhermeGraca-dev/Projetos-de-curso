import "./control-panel.css";
import Timer from "../timer/timer";
import shuffleArray from "../../helpers/shuffle";
import React, { useState, useEffect } from "react";

export default function ControlPanel(props) {
  const [estadoVitoria, setEstadoVitoria] = useState("");
  let classGameStarted = props.gameStarted ? " gameStarted " : "";
  const linhas = [0, 9, 16, 16];
  const colunas = [0, 9, 16, 30];
  const bombas = [0, 10, 40, 99];

  useEffect(() => {
    if (props.textoFim == "BOOMMMMM!!! Fim de jogo"){
      setEstadoVitoria("lblPerdeuSim");
    }
    else if (props.textoFim == "GANHASTE!! Fim de jogo"){
      setEstadoVitoria("lblGanhouSim");
    }
  }, [props.textoFim]);

  useEffect(() => {
    handleStartGame();
  }, [props.nivel]);

  function handleStartGame(){
    let quadradosAux = [];
    let linha = linhas[props.nivel]; 
    let coluna = colunas[props.nivel];
    let bomba = bombas[props.nivel];

    for (let i = 0; i < bomba; i++){
      quadradosAux.push({id: i, nome: "bomba.png", numero: 0, flipped: ""});
    }
    
    for (let i = bomba; i < linha*coluna; i++){
      quadradosAux.push({id: i, nome: "campoVazio.png", numero: 0, flipped: ""});
    }

    quadradosAux = shuffleArray(quadradosAux);
    for (let i = 0; i < linha; i++){
      for (let e = 0; e < coluna; e++){
        let linhaAtual = coluna*i;
        let linhaAnterior = linhaAtual-coluna;
        if (quadradosAux[linhaAtual+e].nome == "bomba.png"){
          //cima
          if (i > 0 && linhaAtual == linhaAtual+e){
            quadradosAux[linhaAnterior].numero++;
            quadradosAux[linhaAnterior+1].numero++;
          }
          else if (i > 0 && linhaAtual+e == linhaAtual+coluna-1){
            quadradosAux[linhaAnterior+coluna-1].numero++;
            quadradosAux[linhaAnterior+coluna-2].numero++;
          }
          else if (i > 0){
            quadradosAux[linhaAnterior+e-1].numero++;
            quadradosAux[linhaAnterior+e].numero++;
            quadradosAux[linhaAnterior+e+1].numero++;
          }

          //linha
          if (linhaAtual == linhaAtual+e){
            quadradosAux[linhaAtual+1].numero++;
          }
          else if (linhaAtual+e == linhaAtual+coluna-1){
            quadradosAux[linhaAtual+coluna-2].numero++;
          }
          else{
            quadradosAux[linhaAtual+e-1].numero++;
            quadradosAux[linhaAtual+e+1].numero++;
          }
          
          //baixo
          if (i < linha-1 && linhaAtual == linhaAtual+e){
            quadradosAux[linhaAtual+coluna].numero++;
            quadradosAux[linhaAtual+coluna+1].numero++;
          }
          else if (i < linha-1 && linhaAtual+e == linhaAtual+coluna-1){
            quadradosAux[linhaAtual+(2*coluna)-1].numero++;
            quadradosAux[linhaAtual+(2*coluna)-2].numero++;
          }
          else if (i < linha-1){
            quadradosAux[linhaAtual+coluna+e-1].numero++;  
            quadradosAux[linhaAtual+coluna+e].numero++;
            quadradosAux[linhaAtual+coluna+e+1].numero++;
          }
        }
      }
    }
    for (let i = 0; i < quadradosAux.length; i++){
      if (quadradosAux[i].numero > 0 && quadradosAux[i].nome != "bomba.png"){
        quadradosAux[i].nome = "numero-" + quadradosAux[i].numero + ".png";
      }
    }
    props.setQuadrados(quadradosAux);
  }

  return (
    <section id="panel-control">
      <form className="form">
        <fieldset className="form-group">
          <h2>Nível:</h2>
          <select 
            disabled={props.gameStarted}
            onChange={(e) => {
              props.nivelFunc(e.target.value);
              handleStartGame();
            }}
            defaultValue={0}
            id="btLevel"
          >
            <option value="0">Seleccione...</option>
            <option value="1">Básico (9x9)</option>
            <option value="2">Intermédio (16x16)</option>
            <option value="3">Avançado (30x16)</option>
          </select>
        </fieldset>
      </form>
      <div className="form-metadata">
        <dl className={"list-item left " + classGameStarted}>
          <dt>Tempo de Jogo:</dt>
          <dd id="gameTime">
            {props.gameStarted && <Timer timeout={0} textoFimJogo={props.textoFim} />}
          </dd>
        </dl>
        <dl className={"list-item left " + classGameStarted}>
          <dt>Bandeiras Restantes</dt>
          <dd id="bandeiras">
            {props.gameStarted && props.bandeiras}
          </dd>
        </dl>
      </div>
      <div id="divResultado">
        <p className={estadoVitoria}>
          {props.textoFim}
        </p>
      </div>
      <button type="button" id="btPlay" onClick={() => {
        if (props.nivel != 0){
          handleStartGame();
          props.handleGameStarted();
        }
      }} >
        {props.gameStarted && props.nivel != 0 ? "Terminar Jogo" : "Iniciar o Jogo"}
      </button>
    </section>
  );
}
