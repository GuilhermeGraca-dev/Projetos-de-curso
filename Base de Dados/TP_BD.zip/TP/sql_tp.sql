/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     13/12/2024 18:56:07                          */
/*==============================================================*/


alter table ALOJADO
   drop constraint FK_ALOJADO_ALOJADO_HOSPEDE;

alter table ALOJADO
   drop constraint FK_ALOJADO_ALOJADO2_QUARTO;

alter table CONTEM
   drop constraint FK_CONTEM_CONTEM_RESERVA;

alter table CONTEM
   drop constraint FK_CONTEM_CONTEM2_HOSPEDE;

alter table COZINHEIRO
   drop constraint FK_COZINHEI_CARGO3_FUNCIONA;

alter table EMPREGADO_LIMPEZA
   drop constraint FK_EMPREGAD_CARGO2_FUNCIONA;

alter table EMPREGADO_MESA
   drop constraint FK_EMPREGAD_CARGO4_FUNCIONA;

alter table ENTRADA
   drop constraint FK_ENTRADA_PROCESSA_RECECION;

alter table EXIGE
   drop constraint FK_EXIGE_EXIGE_ENTRADA;

alter table EXIGE
   drop constraint FK_EXIGE_EXIGE2_RESERVA;

alter table FAZ
   drop constraint FK_FAZ_FAZ_COZINHEI;

alter table FAZ
   drop constraint FK_FAZ_FAZ2_BUFFET;

alter table LIMPA
   drop constraint FK_LIMPA_RELATIONS_EMPREGAD;

alter table LIMPA
   drop constraint FK_LIMPA_RELATIONS_QUARTO;

alter table PEDE
   drop constraint FK_PEDE_PEDE_HOSPEDE;

alter table PEDE
   drop constraint FK_PEDE_PEDE2_BEBIDA;

alter table PEDE
   drop constraint FK_PEDE_PEDE3_BUFFET;

alter table QUARTO
   drop constraint FK_QUARTO_RELATIONS_TIPO_QUA;

alter table RECECIONISTA
   drop constraint FK_RECECION_CARGO_FUNCIONA;

alter table RESERVA
   drop constraint FK_RESERVA_PAGA_METODO_P;

alter table RESERVA
   drop constraint FK_RESERVA_RESPONSAV_HOSPEDE;

alter table SERVE
   drop constraint FK_SERVE_SERVE_EMPREGAD;

alter table SERVE
   drop constraint FK_SERVE_SERVE2_BEBIDA;

alter table TEM
   drop constraint FK_TEM_TEM_RESERVA;

alter table TEM
   drop constraint FK_TEM_TEM2_QUARTO;

drop index ALOJADO2_FK;

drop index ALOJADO_FK;

drop table ALOJADO cascade constraints;

drop table BEBIDA cascade constraints;

drop table BUFFET cascade constraints;

drop index CONTEM2_FK;

drop index CONTEM_FK;

drop table CONTEM cascade constraints;

drop table COZINHEIRO cascade constraints;

drop table EMPREGADO_LIMPEZA cascade constraints;

drop table EMPREGADO_MESA cascade constraints;

drop index PROCESSA_FK;

drop table ENTRADA cascade constraints;

drop index EXIGE2_FK;

drop index EXIGE_FK;

drop table EXIGE cascade constraints;

drop index FAZ2_FK;

drop index FAZ_FK;

drop table FAZ cascade constraints;

drop table FUNCIONARIOS cascade constraints;

drop table HOSPEDE cascade constraints;

drop index RELATIONSHIP_14_FK;

drop index RELATIONSHIP_13_FK;

drop table LIMPA cascade constraints;

drop table METODO_PAGAMENTO cascade constraints;

drop index ASSOCIATION_3_FK;

drop index ASSOCIATION_2_FK;

drop index ASSOCIATION_1_FK;

drop table PEDE cascade constraints;

drop index RELATIONSHIP_3_FK;

drop table QUARTO cascade constraints;

drop table RECECIONISTA cascade constraints;

drop index RESPONSAVEL_FK;

drop index PAGA_FK;

drop table RESERVA cascade constraints;

drop index SERVE_FK;

drop table SERVE cascade constraints;

drop index TEM2_FK;

drop index TEM_FK;

drop table TEM cascade constraints;

drop table TIPO_QUARTO cascade constraints;

/*==============================================================*/
/* Table: ALOJADO                                               */
/*==============================================================*/
create table ALOJADO 
(
   ID_HOSPEDE           NUMBER(4)            not null,
   ID_QUARTO            NUMBER(4)            not null,
   constraint PK_ALOJADO primary key (ID_HOSPEDE, ID_QUARTO)
);

/*==============================================================*/
/* Index: ALOJADO_FK                                            */
/*==============================================================*/
create index ALOJADO_FK on ALOJADO (
   ID_HOSPEDE ASC
);

/*==============================================================*/
/* Index: ALOJADO2_FK                                           */
/*==============================================================*/
create index ALOJADO2_FK on ALOJADO (
   ID_QUARTO ASC
);

/*==============================================================*/
/* Table: BEBIDA                                                */
/*==============================================================*/
create table BEBIDA 
(
   ID_BEBIDA            NUMBER(2)            not null,
   NOME_BEBIDA          CHAR(20),
   PRECO                FLOAT(4),
   constraint PK_BEBIDA primary key (ID_BEBIDA)
);

/*==============================================================*/
/* Table: BUFFET                                                */
/*==============================================================*/
create table BUFFET 
(
   ID_BUFFET            NUMBER(2)            not null,
   DESCRICAO            CHAR(20),
   DATA                 DATE,
   constraint PK_BUFFET primary key (ID_BUFFET)
);

/*==============================================================*/
/* Table: CONTEM                                                */
/*==============================================================*/
create table CONTEM 
(
   ID_RESERVA           NUMBER(4)            not null,
   ID_HOSPEDE           NUMBER(4)            not null,
   constraint PK_CONTEM primary key (ID_RESERVA, ID_HOSPEDE)
);

/*==============================================================*/
/* Index: CONTEM_FK                                             */
/*==============================================================*/
create index CONTEM_FK on CONTEM (
   ID_RESERVA ASC
);

/*==============================================================*/
/* Index: CONTEM2_FK                                            */
/*==============================================================*/
create index CONTEM2_FK on CONTEM (
   ID_HOSPEDE ASC
);

/*==============================================================*/
/* Table: COZINHEIRO                                            */
/*==============================================================*/
create table COZINHEIRO 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   constraint PK_COZINHEIRO primary key (ID_FUNCIONARIOS)
);

/*==============================================================*/
/* Table: EMPREGADO_LIMPEZA                                     */
/*==============================================================*/
create table EMPREGADO_LIMPEZA 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   constraint PK_EMPREGADO_LIMPEZA primary key (ID_FUNCIONARIOS)
);

/*==============================================================*/
/* Table: EMPREGADO_MESA                                        */
/*==============================================================*/
create table EMPREGADO_MESA 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   constraint PK_EMPREGADO_MESA primary key (ID_FUNCIONARIOS)
);

/*==============================================================*/
/* Table: ENTRADA                                               */
/*==============================================================*/
create table ENTRADA 
(
   ID_ENTRADA           NUMBER(4)            not null,
   ID_FUNCIONARIOS      NUMBER(4),
   NOME_HOSPEDES        CHAR(30),
   PRECO_TOTAL          FLOAT(6),
   CHECKIN              DATE,
   CHECKOUT             DATE,
   constraint PK_ENTRADA primary key (ID_ENTRADA)
);

/*==============================================================*/
/* Index: PROCESSA_FK                                           */
/*==============================================================*/
create index PROCESSA_FK on ENTRADA (
   ID_FUNCIONARIOS ASC
);

/*==============================================================*/
/* Table: EXIGE                                                 */
/*==============================================================*/
create table EXIGE 
(
   ID_ENTRADA           NUMBER(4)            not null,
   ID_RESERVA           NUMBER(4)            not null,
   constraint PK_EXIGE primary key (ID_ENTRADA, ID_RESERVA)
);

/*==============================================================*/
/* Index: EXIGE_FK                                              */
/*==============================================================*/
create index EXIGE_FK on EXIGE (
   ID_ENTRADA ASC
);

/*==============================================================*/
/* Index: EXIGE2_FK                                             */
/*==============================================================*/
create index EXIGE2_FK on EXIGE (
   ID_RESERVA ASC
);

/*==============================================================*/
/* Table: FAZ                                                   */
/*==============================================================*/
create table FAZ 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   ID_BUFFET            NUMBER(2)            not null,
   constraint PK_FAZ primary key (ID_FUNCIONARIOS, ID_BUFFET)
);

/*==============================================================*/
/* Index: FAZ_FK                                                */
/*==============================================================*/
create index FAZ_FK on FAZ (
   ID_FUNCIONARIOS ASC
);

/*==============================================================*/
/* Index: FAZ2_FK                                               */
/*==============================================================*/
create index FAZ2_FK on FAZ (
   ID_BUFFET ASC
);

/*==============================================================*/
/* Table: FUNCIONARIOS                                          */
/*==============================================================*/
create table FUNCIONARIOS 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   TURNO                CHAR(10),
   NOME                 CHAR(30),
   constraint PK_FUNCIONARIOS primary key (ID_FUNCIONARIOS)
);

/*==============================================================*/
/* Table: HOSPEDE                                               */
/*==============================================================*/
create table HOSPEDE 
(
   ID_HOSPEDE           NUMBER(4)            not null,
   NIF                  NUMBER(9),
   NOME                 CHAR(30),
   EMAIL                CHAR(30),
   DATA_NASCIMENTO      DATE,
   NUM_TELEMOVEL        NUMBER(9),
   constraint PK_HOSPEDE primary key (ID_HOSPEDE)
);

/*==============================================================*/
/* Table: LIMPA                                                 */
/*==============================================================*/
create table LIMPA 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   ID_QUARTO            NUMBER(4)            not null,
   DATA                 DATE,
   TIPO_LIMPEZA         CHAR(10)
);

/*==============================================================*/
/* Index: RELATIONSHIP_13_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_13_FK on LIMPA (
   ID_FUNCIONARIOS ASC
);

/*==============================================================*/
/* Index: RELATIONSHIP_14_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_14_FK on LIMPA (
   ID_QUARTO ASC
);

/*==============================================================*/
/* Table: METODO_PAGAMENTO                                      */
/*==============================================================*/
create table METODO_PAGAMENTO 
(
   ID_PAGAMENTO         NUMBER(4)            not null,
   TIPO                 CHAR(20),
   constraint PK_METODO_PAGAMENTO primary key (ID_PAGAMENTO)
);

/*==============================================================*/
/* Table: PEDE                                                  */
/*==============================================================*/
create table PEDE 
(
   ID_HOSPEDE           NUMBER(4)            not null,
   ID_BEBIDA            NUMBER(2)            not null,
   ID_BUFFET            NUMBER(2)            not null,
   constraint PK_PEDE primary key (ID_HOSPEDE, ID_BEBIDA, ID_BUFFET)
);

/*==============================================================*/
/* Index: ASSOCIATION_1_FK                                      */
/*==============================================================*/
create index ASSOCIATION_1_FK on PEDE (
   ID_HOSPEDE ASC
);

/*==============================================================*/
/* Index: ASSOCIATION_2_FK                                      */
/*==============================================================*/
create index ASSOCIATION_2_FK on PEDE (
   ID_BEBIDA ASC
);

/*==============================================================*/
/* Index: ASSOCIATION_3_FK                                      */
/*==============================================================*/
create index ASSOCIATION_3_FK on PEDE (
   ID_BUFFET ASC
);

/*==============================================================*/
/* Table: QUARTO                                                */
/*==============================================================*/
create table QUARTO 
(
   ID_QUARTO            NUMBER(4)            not null,
   ID_TIPO              NUMBER(4),
   DISPONIBILIDADE      CHAR(10),
   CAPACIDADE           NUMBER(2),
   PRECO_QUARTO         FLOAT(6),
   constraint PK_QUARTO primary key (ID_QUARTO)
);

/*==============================================================*/
/* Index: RELATIONSHIP_3_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_3_FK on QUARTO (
   ID_TIPO ASC
);

/*==============================================================*/
/* Table: RECECIONISTA                                          */
/*==============================================================*/
create table RECECIONISTA 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   constraint PK_RECECIONISTA primary key (ID_FUNCIONARIOS)
);

/*==============================================================*/
/* Table: RESERVA                                               */
/*==============================================================*/
create table RESERVA 
(
   ID_RESERVA           NUMBER(4)            not null,
   ID_PAGAMENTO         NUMBER(4),
   ID_HOSPEDE           NUMBER(4),
   ESTADO_RESERVA       CHAR(10),
   NUM_NOITES           NUMBER(3),
   N_PESSOAS            NUMBER(2),
   constraint PK_RESERVA primary key (ID_RESERVA)
);

/*==============================================================*/
/* Index: PAGA_FK                                               */
/*==============================================================*/
create index PAGA_FK on RESERVA (
   ID_PAGAMENTO ASC
);

/*==============================================================*/
/* Index: RESPONSAVEL_FK                                        */
/*==============================================================*/
create index RESPONSAVEL_FK on RESERVA (
   ID_HOSPEDE ASC
);

/*==============================================================*/
/* Table: SERVE                                                 */
/*==============================================================*/
create table SERVE 
(
   ID_FUNCIONARIOS      NUMBER(4)            not null,
   ID_BEBIDA            NUMBER(2)            not null,
   constraint PK_SERVE primary key (ID_FUNCIONARIOS, ID_BEBIDA)
);

/*==============================================================*/
/* Index: SERVE_FK                                              */
/*==============================================================*/
create index SERVE_FK on SERVE (
   ID_FUNCIONARIOS ASC
);

/*==============================================================*/
/* Table: TEM                                                   */
/*==============================================================*/
create table TEM 
(
   ID_RESERVA           NUMBER(4)            not null,
   ID_QUARTO            NUMBER(4)            not null,
   constraint PK_TEM primary key (ID_RESERVA, ID_QUARTO)
);

/*==============================================================*/
/* Index: TEM_FK                                                */
/*==============================================================*/
create index TEM_FK on TEM (
   ID_RESERVA ASC
);

/*==============================================================*/
/* Index: TEM2_FK                                               */
/*==============================================================*/
create index TEM2_FK on TEM (
   ID_QUARTO ASC
);

/*==============================================================*/
/* Table: TIPO_QUARTO                                           */
/*==============================================================*/
create table TIPO_QUARTO 
(
   ID_TIPO              NUMBER(4)            not null,
   DESIGNACAO           CHAR(30),
   constraint PK_TIPO_QUARTO primary key (ID_TIPO)
);

alter table ALOJADO
   add constraint FK_ALOJADO_ALOJADO_HOSPEDE foreign key (ID_HOSPEDE)
      references HOSPEDE (ID_HOSPEDE);

alter table ALOJADO
   add constraint FK_ALOJADO_ALOJADO2_QUARTO foreign key (ID_QUARTO)
      references QUARTO (ID_QUARTO);

alter table CONTEM
   add constraint FK_CONTEM_CONTEM_RESERVA foreign key (ID_RESERVA)
      references RESERVA (ID_RESERVA);

alter table CONTEM
   add constraint FK_CONTEM_CONTEM2_HOSPEDE foreign key (ID_HOSPEDE)
      references HOSPEDE (ID_HOSPEDE);

alter table COZINHEIRO
   add constraint FK_COZINHEI_CARGO3_FUNCIONA foreign key (ID_FUNCIONARIOS)
      references FUNCIONARIOS (ID_FUNCIONARIOS);

alter table EMPREGADO_LIMPEZA
   add constraint FK_EMPREGAD_CARGO2_FUNCIONA foreign key (ID_FUNCIONARIOS)
      references FUNCIONARIOS (ID_FUNCIONARIOS);

alter table EMPREGADO_MESA
   add constraint FK_EMPREGAD_CARGO4_FUNCIONA foreign key (ID_FUNCIONARIOS)
      references FUNCIONARIOS (ID_FUNCIONARIOS);

alter table ENTRADA
   add constraint FK_ENTRADA_PROCESSA_RECECION foreign key (ID_FUNCIONARIOS)
      references RECECIONISTA (ID_FUNCIONARIOS);

alter table EXIGE
   add constraint FK_EXIGE_EXIGE_ENTRADA foreign key (ID_ENTRADA)
      references ENTRADA (ID_ENTRADA);

alter table EXIGE
   add constraint FK_EXIGE_EXIGE2_RESERVA foreign key (ID_RESERVA)
      references RESERVA (ID_RESERVA);

alter table FAZ
   add constraint FK_FAZ_FAZ_COZINHEI foreign key (ID_FUNCIONARIOS)
      references COZINHEIRO (ID_FUNCIONARIOS);

alter table FAZ
   add constraint FK_FAZ_FAZ2_BUFFET foreign key (ID_BUFFET)
      references BUFFET (ID_BUFFET);

alter table LIMPA
   add constraint FK_LIMPA_RELATIONS_EMPREGAD foreign key (ID_FUNCIONARIOS)
      references EMPREGADO_LIMPEZA (ID_FUNCIONARIOS);

alter table LIMPA
   add constraint FK_LIMPA_RELATIONS_QUARTO foreign key (ID_QUARTO)
      references QUARTO (ID_QUARTO);

alter table PEDE
   add constraint FK_PEDE_PEDE_HOSPEDE foreign key (ID_HOSPEDE)
      references HOSPEDE (ID_HOSPEDE);

alter table PEDE
   add constraint FK_PEDE_PEDE2_BEBIDA foreign key (ID_BEBIDA)
      references BEBIDA (ID_BEBIDA);

alter table PEDE
   add constraint FK_PEDE_PEDE3_BUFFET foreign key (ID_BUFFET)
      references BUFFET (ID_BUFFET);

alter table QUARTO
   add constraint FK_QUARTO_RELATIONS_TIPO_QUA foreign key (ID_TIPO)
      references TIPO_QUARTO (ID_TIPO);

alter table RECECIONISTA
   add constraint FK_RECECION_CARGO_FUNCIONA foreign key (ID_FUNCIONARIOS)
      references FUNCIONARIOS (ID_FUNCIONARIOS);

alter table RESERVA
   add constraint FK_RESERVA_PAGA_METODO_P foreign key (ID_PAGAMENTO)
      references METODO_PAGAMENTO (ID_PAGAMENTO);

alter table RESERVA
   add constraint FK_RESERVA_RESPONSAV_HOSPEDE foreign key (ID_HOSPEDE)
      references HOSPEDE (ID_HOSPEDE);

alter table SERVE
   add constraint FK_SERVE_SERVE_EMPREGAD foreign key (ID_FUNCIONARIOS)
      references EMPREGADO_MESA (ID_FUNCIONARIOS);

alter table SERVE
   add constraint FK_SERVE_SERVE2_BEBIDA foreign key (ID_BEBIDA)
      references BEBIDA (ID_BEBIDA);

alter table TEM
   add constraint FK_TEM_TEM_RESERVA foreign key (ID_RESERVA)
      references RESERVA (ID_RESERVA);

alter table TEM
   add constraint FK_TEM_TEM2_QUARTO foreign key (ID_QUARTO)
      references QUARTO (ID_QUARTO);

