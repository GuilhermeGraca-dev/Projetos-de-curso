INSERT INTO HOSPEDE VALUES(2, 123456789, 'JOAO','MARIA@LOCAL','2021-12-23', 112456789);
INSERT INTO HOSPEDE VALUES(3, 123456789, 'GUILHERME','GUILHERME@LOCAL','2005-02-03', 112456789);
INSERT INTO HOSPEDE VALUES(1, 123456789, 'GABRIEL','GABRIEL@LOCAL','2025-04-13', 112456789);
INSERT INTO HOSPEDE VALUES(4, 123456789, 'RODRIGO','RODRIGO@LOCAL','2003-04-13', 112456789);

INSERT INTO METODO_PAGAMENTO VALUES (12, 'MB');
INSERT INTO METODO_PAGAMENTO VALUES (11, 'MB');

INSERT INTO RESERVA VALUES (12, 12, 3, 'LIMPO', 5, 8);
INSERT INTO RESERVA VALUES (13, 12, 3, 'POR LIMPAR', 4, 10);
INSERT INTO RESERVA VALUES (14, 12, 3, 'MUITO SUJO', 7, 25);
INSERT INTO RESERVA VALUES (11, 11, 1, 'SUJO', 2, 4);

INSERT INTO FUNCIONARIOS VALUES (10,'Noite', 'Ana');
INSERT INTO FUNCIONARIOS VALUES (11,'Manha', 'Rodrigo');
INSERT INTO FUNCIONARIOS VALUES (12,'Tarde', 'Guilherme');

INSERT INTO EMPREGADO_LIMPEZA VALUES (10);
INSERT INTO EMPREGADO_LIMPEZA VALUES (11);
INSERT INTO EMPREGADO_LIMPEZA VALUES (12);

INSERT INTO TIPO_QUARTO VALUES (10, 'Simples');

INSERT INTO QUARTO VALUES (15, 10, 'Sim' , 10, 20);

INSERT INTO LIMPA VALUES (10, 15, '2024-12-13', 'Completa');
INSERT INTO LIMPA VALUES (12, 15, '2021-11-15', 'Basica');
INSERT INTO LIMPA VALUES (11, 15, '2024-02-21', 'Total');
INSERT INTO LIMPA VALUES (10, 15, '2024-02-21', 'Total');
INSERT INTO LIMPA VALUES (10, 15, '2022-02-21', 'Total');





//vista 1
SELECT nome,FLOOR(TO_CHAR(SYSDATE,'YYYY') - TO_CHAR(DATA_NASCIMENTO,'YYYY')) IDADE
FROM hospede
WHERE FLOOR(TO_CHAR(SYSDATE,'YYYY') - TO_CHAR(DATA_NASCIMENTO,'YYYY')) = (SELECT MAX(FLOOR(TO_CHAR(SYSDATE,'YYYY') - TO_CHAR(DATA_NASCIMENTO,'YYYY'))) FROM HOSPEDE) 
ORDER BY data_nascimento;


//vista 2
SELECT ID_RESERVA, NUM_NOITES
FROM RESERVA
WHERE NUM_NOITES = (SELECT MAX(NUM_NOITES) FROM RESERVA)
ORDER BY ID_RESERVA;

//vista 3
SELECT H.id_hospede, H.Nome, COUNT(R.id_reserva) AS total_reservas
FROM Hospede H
JOIN Reserva R ON H.id_hospede = R.id_hospede
GROUP BY H.id_hospede, H.Nome
HAVING COUNT(R.id_reserva) = (
    SELECT MAX(total_reservas)
    FROM (
        SELECT R2.id_hospede, COUNT(R2.id_reserva) AS total_reservas
        FROM Reserva R2
        GROUP BY R2.id_hospede
    ) Subquery
);

//vista 4
SELECT f.Nome AS empregado_limpeza, COUNT(*) AS total_limpezas
FROM limpa l
JOIN funcionarios f ON l.id_funcionarios = f.id_funcionarios
GROUP BY f.Nome
HAVING COUNT(*) = (
        SELECT 
            MAX(total_limpezas)
        FROM (
            SELECT 
                COUNT(*) AS total_limpezas
            FROM 
                limpa l
                JOIN funcionarios f ON l.id_funcionarios = f.id_funcionarios
            GROUP BY 
                l.id_funcionarios
        )
    );


//vista 5
SELECT R.id_reserva, R.n_pessoas
FROM Reserva R
WHERE R.n_pessoas = (
    SELECT MAX(R2.n_pessoas)
    FROM Reserva R2
);



